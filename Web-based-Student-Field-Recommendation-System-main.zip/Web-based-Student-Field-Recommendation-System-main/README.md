# Recommending-the-suitable-major-for-Students-readme
## Tabl of Content
[**Dataset**](https://github.com/hussain0048/An-intellegint-recommendation-system-for-students-specialization-using-machine-learning/tree/main/Dataset)
 * [Campus Recruitment](https://www.kaggle.com/benroshan/factors-affecting-campus-placement)
 * [CMS-R-2020](https://github.com/DG1606/CMS-R-2020)
[**Related Papers**](https://github.com/hussain0048/An-intellegint-recommendation-system-for-students-specialization-using-machine-learning/tree/main/Related%20Papers)
  * [Student Knowledge based Advisor System](https://github.com/hussain0048/An-intellegint-recommendation-system-for-students-specialization-using-machine-learning/blob/main/Related%20Papers/Students%20Knowledge%20based%20Advisor%20System.pdf)
  * [Intelligent Model for Suitable University Specialization Selection in Palestine](https://github.com/hussain0048/An-intellegint-recommendation-system-for-students-specialization-using-machine-learning/blob/main/Related%20Papers/Intelligent%20Model%20for%20Suitable%20University%20Specialization%20Selection%20in%20Palestine.pdf)
  * [ Fordham University](https://datasetsearch.research.google.com/search?query=%20Fordham%20University&docid=L2cvMTFqbnpjbGY5MQ%3D%3D)
  * [EvalMl AutoML Library](https://medium.com/geekculture/evalml-automl-library-96ac29c80248)
  * [Feature Selection Techniqu](https://medium.com/geekculture/feature-selection-techniques-bc0c69e85b85)
 
 
 
 


